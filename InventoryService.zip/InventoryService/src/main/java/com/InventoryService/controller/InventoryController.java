package com.InventoryService.controller;

import com.InventoryService.model.Inventory;
import com.InventoryService.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
    @RequestMapping("/inventory")
    public class InventoryController {

        @PostMapping
        public ResponseEntity<String> addInventory(@RequestBody Inventory inventory) {
            // Save to database logic
                inventoryService.saveInventory(inventory);
            return ResponseEntity.ok("Inventory added successfully");
        }

        @Autowired
        private InventoryService inventoryService;

        @GetMapping("/check")
        public boolean checkInventory(@RequestParam String product, @RequestParam int quantity) {
            return inventoryService.isProductAvailable(product, quantity);
        }
    }



