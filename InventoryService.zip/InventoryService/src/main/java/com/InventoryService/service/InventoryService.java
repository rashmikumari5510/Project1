package com.InventoryService.service;

import com.InventoryService.model.Inventory;
import com.InventoryService.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    public boolean isProductAvailable(String product, int quantity) {
     //   return inventoryRepository.findByProduct(product)


//        Optional<Inventory> inventory = inventoryRepository.findByProduct(product);
//        // If product is found and stock is greater than or equal to the requested quantity
//        return inventory.isPresent();
//    }



    Optional<Inventory> inventory = inventoryRepository.findByProduct(product);

    // Check if product exists and has sufficient stock
        return inventory.isPresent() && inventory.get().getStock() >= quantity;
}




//                .map(inventory -> inventory.getStock() >= quantity)
//                .orElse(false);
//    }

    public void saveInventory(Inventory inventory) {
        inventoryRepository.save(inventory);
    }
}

